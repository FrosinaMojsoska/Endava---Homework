﻿using System;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using UnitTestingAssert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;
using NUnitAssert = NUnit.Framework.Assert;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;

namespace UnitTestProject1
{
    public class User
        {
        public string LastName { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }

        }

    [TestFixture]
    public class UnitTest1
    {



        User user1 = new User();
        public ChromeDriver driver;
        private WebDriverWait webDriverWait;

        [SetUp]
        public void BeforeEach()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://trainingrite.net/");
            driver.Manage().Window.Maximize();
        }

        [Test]
        public void TestMethod1()
        {
            //selectors
            string FirstNameSelector = "ctl00_MainContent_txtFirstName";
            string LastNameSelector = "ctl00_MainContent_txtLastName";
            string EmailSelector = "ctl00_MainContent_txtEmail";
            string PasswordSelector = "ctl00_MainContent_txtPassword";
            string VerifyPasswordSelector = "ctl00_MainContent_txtVerifyPassword";
            string HomePhoneSelector = "ctl00_MainContent_txtHomePhone";
            string CellPhoneSelector = "ctl00_MainContent_txtCellPhone";
            string InstructionsSelector = "ctl00_MainContent_txtInstructions";

      
            user1.LastName = "Mojsoska";
            user1.PhoneNumber = "012";
            user1.Password = "Password123";

            IWebElement signUpButton = driver.FindElement(By.CssSelector("input[value='Sign Up']"));
            signUpButton.Click();
            
            IWebElement firstNameInput = driver.FindElement(By.Id(FirstNameSelector));
            firstNameInput.SendKeys("Frosina");
            IWebElement lastNameInput = driver.FindElement(By.Id(LastNameSelector));
            lastNameInput.SendKeys("Mojsoska");
            IWebElement emailInput = driver.FindElement(By.Id(EmailSelector));
            emailInput.SendKeys("frosina_mojsoska@hotmail.com");
            IWebElement passwordInput = driver.FindElement(By.Id(PasswordSelector));
            passwordInput.SendKeys("Password123");
            IWebElement verifyPassword = driver.FindElement(By.Id(VerifyPasswordSelector));
            verifyPassword.SendKeys("Password123");
            IWebElement homePhoneInput = driver.FindElement(By.Id(HomePhoneSelector));
            homePhoneInput.SendKeys("012");
            IWebElement cellPhoneInput = driver.FindElement(By.Id(CellPhoneSelector));
            cellPhoneInput.SendKeys("012");
            IWebElement instructionsInput = driver.FindElement(By.Id(InstructionsSelector));
            instructionsInput.SendKeys("Some text here");
            IWebElement submitButton = driver.FindElementById("ctl00_MainContent_btnSubmit");
            submitButton.Click();
            string expectedInformation = "Customer information added successfully";
            string actualInformation = driver.FindElementById("ctl00_MainContent_lblTransactionResult").Text;
            UnitTestingAssert.AreEqual(expectedInformation, actualInformation, "Something went wrong and the customer is not added");
           

            NUnitAssert.Multiple(() =>
                {
                    string firstNameAfterSubmit = driver.FindElement(By.Id(FirstNameSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(firstNameAfterSubmit);
                    string lastNameAfterSubmit = driver.FindElement(By.Id(LastNameSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(lastNameAfterSubmit);
                    string emailAfterSubmit = driver.FindElement(By.Id(EmailSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(emailAfterSubmit);
                    string passwordAfterSubmit = driver.FindElement(By.Id(PasswordSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(passwordAfterSubmit);
                    string verifyPasswordAfterSubmit = driver.FindElement(By.Id(VerifyPasswordSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(verifyPasswordAfterSubmit);
                    string homePhoneAfterSubmit = driver.FindElement(By.Id(HomePhoneSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(homePhoneAfterSubmit);
                    string cellPhoneAfterSubmit = driver.FindElement(By.Id(CellPhoneSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(cellPhoneAfterSubmit);
                    string instructionsAfterSubmit = driver.FindElement(By.Id(InstructionsSelector)).GetAttribute("value");
                    NUnitAssert.IsEmpty(instructionsAfterSubmit);
                });


        }


        [Test]
        public void TestMethod2()
        {

            IWebElement LoginPhoneInput = driver.FindElement(By.Id("txtphone"));
            LoginPhoneInput.SendKeys("012");
            IWebElement LoginPasswordInput = driver.FindElement(By.Id("txtpassword"));
            LoginPasswordInput.SendKeys("Password123");
            IWebElement LoginSubmitButton = driver.FindElement(By.Id("btnSubmit"));
            LoginSubmitButton.Click();
            IWebElement UserSurname = driver.FindElement(By.Name("loggedLN"));
            IWebElement UserPhone = driver.FindElement(By.Id("custphone"));
            string Surname = UserSurname.Text;
            string Phone = UserPhone.Text.Substring(17);

            UnitTestingAssert.AreEqual(user1.LastName, Surname, "The username is not the same");
            UnitTestingAssert.AreEqual(user1.PhoneNumber, Phone, "The phone is not the same");
            //Customer Phone#: 012


        }
        [Test]

        public void TestMethod3()
        {
            
            IWebElement PricingAndDiscountLink = driver.FindElement(By.CssSelector("a[href='coursecatalog.aspx']"));
            PricingAndDiscountLink.Click();          
            webDriverWait = new WebDriverWait(driver, new TimeSpan(0, 0, 5));
            webDriverWait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("a[href='https://www.paypal.com/us/verified/pal=mktg%40trainingrite%2enet']"))).Click();
            
            driver.SwitchTo().Window(driver.WindowHandles[1]);
            string expectedUrl = "https://www.paypal.com/us/verified/pal=mktg%40trainingrite.net";
            string currentUrl = driver.Url;
            UnitTestingAssert.AreEqual(expectedUrl, currentUrl, "Urls not match");
            driver.SwitchTo().Window(driver.WindowHandles[0]);
            IWebElement HomeLink = driver.FindElement(By.CssSelector("a[href='default.aspx']"));
            HomeLink.Click();
               
        }

        [TearDown]
        public void AfterEach()
        {
            driver.Quit();
          // driver.Close();
        }
    }
}
